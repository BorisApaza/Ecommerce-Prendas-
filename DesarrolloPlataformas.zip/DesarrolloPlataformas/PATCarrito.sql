use BDProyecto

create proc spEliminarCarrito
@id bigint
as
if not exists (select * from Detalle_Producto where id_Carrito =@id)
if not exists (select * from Pedido where idCarrito=@id)
	begin
	delete Carrito_Compras where idCarrito=@id
	select CodError =0, Mensaje= 'Eliminacion correcta' 
	end
else select CodError =1, Mensaje= 'El carrito tiene pedido' 

create proc spAgregarCarrito
@bol BIT
as
 insert into Carrito_Compras(bug) values (@bol)
 select CodError =0, Mensaje= 'Insercion correcta'
 spAgregarCarrito '0'
 create proc spBuscarCarrito
 as
 select MAX(idCarrito) from Carrito_Compras

 SELECT * FROM Detalle_Producto


 create proc spListarDetalleCarrito
@id bigint
as
select Producto.Nombre,Detalle_Producto.cantidad,Producto.Color,Producto.Talla,(Detalle_Producto.cantidad * Producto.Precio),Detalle_Producto.idDetalle
from Producto Full OUTER JOIN Detalle_Producto
ON	Detalle_Producto.id_Producto =Producto.idProducto 
where Detalle_Producto.id_Carrito=@id
spListarDetalleCarrito '22'