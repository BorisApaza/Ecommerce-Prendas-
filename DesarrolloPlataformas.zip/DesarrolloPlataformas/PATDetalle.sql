use BDProyecto

create proc spAgregarDetalle
@NombreProducto varchar(50),@idCarrito bigint, @cantidad int
as
if exists (select * from Carrito_Compras where idCarrito=@idCarrito) 
	if exists (select * from Producto where Nombre=@NombreProducto)	
		begin
		declare @idProducto bigint
		set @idProducto= (select idProducto  from Producto where Nombre=@NombreProducto)
		insert into Detalle_Producto (id_Producto,cantidad,id_Carrito) values(@idProducto,@cantidad,@idCarrito)
		select CodError =0, Mensaje= 'Se agrego' 
		end
	else select CodError =1, Mensaje= 'No existe el producto' 
else select CodError =1, Mensaje= 'No se creo carrito' 

spAgregarDetalle 'pol','02','12'

create proc spEliminarDetalle
@NombreProducto varchar(50),@IdCarrito bigint
as
if exists(select * from Producto where Nombre=@NombreProducto)
	begin
	declare @idProducto varchar(50)
	set @idProducto = (select idProducto from Producto where Nombre=@NombreProducto)
	if exists (select * from Detalle_Producto where id_Producto=@idProducto and id_Carrito=@IdCarrito)
	begin
	delete Detalle_Producto where id_Producto=@idProducto and id_Carrito=@IdCarrito
	select CodError =0, Mensaje= 'se elimino'  
	end
	else select CodError =1, Mensaje= 'No se existe detalle o carrito'  
	end
else select CodError =1, Mensaje= 'No se existe producto' 
spEliminarDetalle 'polera','01'

create proc spBuscarDetalle
@IdCarrito bigint
as
if exists(select * from Detalle_Producto where id_Carrito=@IdCarrito)
	begin
	select * from Detalle_Producto where id_Carrito=@IdCarrito
	select CodError =0, Mensaje= 'exito'  
	end
else select CodError =1, Mensaje= 'No se existe detalle'  