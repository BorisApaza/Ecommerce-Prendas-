use BDProyecto
create proc spAgregarPedido
	@NombreCliente varchar(30),
	@APaternoCliente varchar(30),
	@AMaternoCliente varchar(30),
	@CelularCliente varchar(15),
	@Correo varchar(30),
	@Pais varchar(25),
	@Provincia varchar(20),
	@Distrito varchar(20),
	@Direccion varchar(30),
	@idCarrito bigint
	as
	if exists(select* from Carrito_Compras where idCarrito=@idCarrito)
		begin
		insert into Pedido   
		(NombreCliente,
		APaternoCliente,
		AMaternoCliente,
		CelularCliente,
		Correo ,
		Pais ,
		Provincia,
		Distrito,
		Direccion ,
		idCarrito) values(
		@NombreCliente,
		@APaternoCliente,
		@AMaternoCliente,
		@CelularCliente,
		@Correo ,
		@Pais ,
		@Provincia,
		@Distrito,
		@Direccion ,
		@idCarrito)
		select CodError =0, Mensaje= 'Se creo pedido' 
		end
	else select CodError =1, Mensaje= 'No existe carrito' 


create proc spEliminarPedido
	@NombreCliente varchar(30),
	@idCarrito bigint
	as
	if exists(select* from Pedido where idCarrito=@idCarrito and NombreCliente=@NombreCliente)
		begin
		delete Pedido where  idCarrito=@idCarrito and NombreCliente=@NombreCliente
		delete Detalle_Producto where id_Carrito= @idCarrito
		delete Carrito_Compras where idCarrito=@idCarrito
		select CodError =0, Mensaje= 'Se elimino pedido' 
		end
	else select CodError =1, Mensaje= 'No existe pedido' 

create proc spBuscarPedido
	@NombreCliente varchar(30)
	as
	select * from Pedido where NombreCliente=@NombreCliente