﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidades;
using System.Data;// buffer de mememori
namespace CapaNegocios.Interfaces
{
    interface IDetalle
    {
        bool Agregar(string nombre,Detalle_Producto detalle);

        bool Eliminar( string nombre,Detalle_Producto detalle);

        DataTable Buscar(Detalle_Producto detalle);
    }
}
