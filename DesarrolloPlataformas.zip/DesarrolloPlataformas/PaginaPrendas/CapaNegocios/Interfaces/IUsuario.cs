﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidades;
using System.Data;// buffer de mememoria
namespace CapaNegocios.Interfaces
{
    interface IUsuario
    {
        bool Login(Usuario usuario);

        bool Eliminar(Usuario usuario);

        bool Agregar(Usuario usuario);

        DataTable Listar();

        bool Modificar(Usuario usuario, String usuario2,String contraseña);

        DataTable Buscar(Usuario usuario);
    }
}
