﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidades;
using System.Data;// buffer de mememoria
namespace CapaNegocios.Interfaces
{
    interface IProducto
    {
        bool Agregar(Producto producto);

        bool Eliminar(Producto producto);


        bool Modificar(Producto producto, String nombre2, String color, String Talla, long Precio);

        DataTable Listar();

        DataTable Buscar(Producto producto);
    }
}
