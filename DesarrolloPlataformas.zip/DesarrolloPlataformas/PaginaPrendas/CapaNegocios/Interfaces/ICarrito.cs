﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidades;
using System.Data;// buffer de mememori
namespace CapaNegocios.Interfaces
{
    interface ICarrito
    {
        bool Agregar(Carrito_Compras carrito);

        bool Eliminar(Carrito_Compras carrito);

        double Buscar();

        DataTable ListarDetalle(Carrito_Compras carrito);
    }
}
