﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaNegocios;
using CapaDatos;
using CapaEntidades;
using System.Data;
namespace CapaNegocios
{
    public class CarritoBL: Interfaces.ICarrito
    {
        private Datos datos = new DatosSQL();

        private string mensaje;

        public string Mensaje
        { get { return mensaje; } }

        public bool Agregar(Carrito_Compras carrito)
        {
            DataRow fila = datos.TraerDataRow("spAgregarCarrito",carrito._bug);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public bool Eliminar(Carrito_Compras carrito)
        {
            DataRow fila = datos.TraerDataRow("spEliminarCarrito", carrito._id);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public double Buscar()
        {
            double a;
            a = Convert.ToDouble(datos.TraerValor("spBuscarCarrito").ToString());

            return a;
        }

        public DataTable ListarDetalle(Carrito_Compras carrito) {
            DataTable a = new DataTable();
            a = datos.TraerDataTable("spListarDetalleCarrito", carrito._id);
            return a;
        }

    }
}
