﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaNegocios;
using CapaDatos;
using CapaEntidades;
using System.Data;
namespace CapaNegocios
{
   public class DetalleBL : Interfaces.IDetalle
    {
        private Datos datos = new DatosSQL();

        private string mensaje;

        public string Mensaje
        { get { return mensaje; } }

        public bool Agregar( string nombre,Detalle_Producto detalle)
        {
            DataRow fila = datos.TraerDataRow("spAgregarDetalle", nombre, detalle._idCarrito, detalle._Cantidad);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public bool Eliminar( string nombre,Detalle_Producto detalle)
        {
            DataRow fila = datos.TraerDataRow("spEliminarDetalle", nombre, detalle._idCarrito);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public DataTable Buscar(Detalle_Producto detalle) {
            return datos.TraerDataTable("spBuscarDetalle", detalle._id);
        }
    }
}
