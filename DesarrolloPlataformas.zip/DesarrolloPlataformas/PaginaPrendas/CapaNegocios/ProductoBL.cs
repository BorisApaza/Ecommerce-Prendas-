﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaNegocios;
using CapaDatos;
using CapaEntidades;
using System.Data;
namespace CapaNegocios
{
   public class ProductoBL : Interfaces.IProducto
    {
        private Datos datos = new DatosSQL();

        private string mensaje;

        public string Mensaje
        { get { return mensaje; } }

        public DataTable Listar()
        {
            return datos.TraerDataTable("spListarProducto");
        }

        public bool Agregar(Producto producto)
        {
            DataRow fila = datos.TraerDataRow("spAgregarProducto",producto._Nombre,producto._Color,producto._Talla,producto._Precio);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public bool Eliminar(Producto producto)
        {
            DataRow fila = datos.TraerDataRow("spEliminarProducto", producto._Nombre);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public bool Modificar(Producto producto, string Nombre2,string color, string talla,long precio)
        {
            DataRow fila = datos.TraerDataRow("spModificarProducto", producto._Nombre, Nombre2, color, talla, precio);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }


        public DataTable Buscar(Producto producto)
        {
            return datos.TraerDataTable("spBuscarProducto", producto._Nombre);
        }
    }
}
