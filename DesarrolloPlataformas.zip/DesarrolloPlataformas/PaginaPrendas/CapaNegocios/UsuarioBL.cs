﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaNegocios;
using CapaDatos;
using CapaEntidades;
using System.Data;

namespace CapaNegocios
{
    public class UsuarioBL : Interfaces.IUsuario
    {
        private Datos datos = new DatosSQL();

        private string mensaje;

        public string Mensaje
        { get { return mensaje; } }

        public bool Login(Usuario usuario)
        {
            DataRow fila = datos.TraerDataRow("spLoginUsuario", usuario._Usuario, usuario._Contrasena);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }
        public bool Modificar(Usuario usuario, string usuario2,string contra)
        {
            DataRow fila = datos.TraerDataRow("spModificarUsuario", usuario._Usuario, usuario2, contra);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public bool Eliminar( Usuario usuario)
        {
            DataRow fila = datos.TraerDataRow("spEliminarUsuario", usuario._Usuario);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public bool Agregar(Usuario usuario)
        {
            DataRow fila = datos.TraerDataRow("spAgregarUsuario",usuario._Usuario, usuario._Contrasena);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public DataTable Listar()
        {
            return datos.TraerDataTable("spListarUsuario");
        }

        public DataTable Buscar(Usuario usuario)
        {
            return datos.TraerDataTable("spBuscarUsuario", usuario._Usuario);
        }


       
    }
}
