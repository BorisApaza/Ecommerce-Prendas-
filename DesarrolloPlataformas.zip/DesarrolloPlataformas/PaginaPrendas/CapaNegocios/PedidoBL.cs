﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaNegocios;
using CapaDatos;
using CapaEntidades;
using System.Data;
namespace CapaNegocios
{
   public class PedidoBL : Interfaces.IPedido
    {
        private Datos datos = new DatosSQL();

        private string mensaje;

        public string Mensaje
        { get { return mensaje; } }
        public bool Agregar(Pedido pedido)
        {
            DataRow fila = datos.TraerDataRow("spAgregarPedido", pedido._NombreCliente,pedido._APaternoCliente,pedido._APMaternoCliente,pedido._CelularCliente,pedido._Correo,pedido._Pais,pedido._Provincia,
                pedido._Distrito,pedido._Direccion,pedido._idCarrito);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public bool Eliminar(Pedido pedido)
        {
            DataRow fila = datos.TraerDataRow("spEliminarPedido",pedido._NombreCliente,pedido._idCarrito);
            byte codError = Convert.ToByte(fila["CodError"]);
            mensaje = fila["Mensaje"].ToString();
            if (codError == 0) return true;
            else return false;
        }

        public DataTable Buscar(Pedido pedido)
        {
            return datos.TraerDataTable("spBuscarPedido", pedido._NombreCliente);
        }
    }
}
