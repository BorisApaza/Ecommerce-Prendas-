﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Runtime.Serialization;
namespace CapaEntidades
{
    [DataContract]
    public class Carrito_Compras
    {
        [DataMember]
        public long _id
        { get; set; }
        [DataMember]
        public Boolean _bug
        { get; set; }
    }
}
