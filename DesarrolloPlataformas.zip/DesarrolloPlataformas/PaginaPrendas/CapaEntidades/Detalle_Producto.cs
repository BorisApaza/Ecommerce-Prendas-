﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Runtime.Serialization;
namespace CapaEntidades
{
   [DataContract]
    public class Detalle_Producto
    {
        [DataMember]
        public long _id
        { get; set; }
        [DataMember]
        public int _Cantidad
        { get; set; }
        [DataMember]
        public long _idProducto
        { get; set; }
        [DataMember]
        public long _idCarrito
        { get; set; }

    }
}
