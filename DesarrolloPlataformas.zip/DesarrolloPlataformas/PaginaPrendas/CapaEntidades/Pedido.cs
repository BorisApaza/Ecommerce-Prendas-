﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Runtime.Serialization;
namespace CapaEntidades
{
    [DataContract]
    public class Pedido
    {
        [DataMember]
        public long _id
        { get; set; }
        [DataMember]
        public string _NombreCliente
        { get; set; }
        [DataMember]
        public string _APaternoCliente
        { get; set; }
        [DataMember]
        public string _APMaternoCliente
        { get; set; }
        [DataMember]
        public string _CelularCliente
        { get; set; }
        [DataMember]
        public string _Correo
        { get; set; }
        [DataMember]
        public string _Pais
        { get; set; }
         [DataMember]
        public string _Provincia
        { get; set; }
         [DataMember]
         public string _Distrito
         { get; set; }
         [DataMember]
         public string _Direccion
         { get; set; }
         [DataMember]
         public long _idCarrito
         { get; set; }
         
    }
}
