﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Runtime.Serialization;
namespace CapaEntidades
{
    [DataContract]
    public class Producto
    {
        [DataMember]
        public string _Nombre
        { get; set; }
        [DataMember]
        public string _Color
        { get; set; }
        [DataMember]
        public string _Talla
        { get; set; }
        [DataMember]
        public long _Precio
        { get; set; }
        [DataMember]
        public string _Imagen
        { get; set; }
    }
}
