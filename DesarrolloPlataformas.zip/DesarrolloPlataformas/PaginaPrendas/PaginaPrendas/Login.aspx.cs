﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security; // Namesapace para manejar seguridad 
using System.Security.Cryptography;
namespace PaginaPrendas
{
    public partial class Lofin2 : System.Web.UI.Page
    {
        ServiceReference1.WSUsuarioSoapClient servicio = new ServiceReference1.WSUsuarioSoapClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            Login1.FailureText = " no tiene acceso al sistema";
            string usuario = Login1.UserName;
            string password = Login1.Password;
            
            string[] valores = servicio.Login(usuario, password).ToArray();
            if(valores[0]=="0"){
                FormsAuthentication.RedirectFromLoginPage(usuario, false);
            }else 
            Login1.FailureText = valores[1];
        }
    }
}