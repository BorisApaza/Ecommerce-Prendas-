﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.IO;

using System.Web.UI.HtmlControls;
using System.Text;
namespace PaginaPrendas.Intranet
{
    public partial class Staf : System.Web.UI.Page
    {
        ServiceReferenceCarrito.WSCarritoSoapClient servicioCarrito = new ServiceReferenceCarrito.WSCarritoSoapClient();
        ServiceReferenceDetalle.WSDetalleSoapClient servicioDetalle = new ServiceReferenceDetalle.WSDetalleSoapClient();
        ServiceReferenceProducto.WSProductoSoapClient servicioProducto = new ServiceReferenceProducto.WSProductoSoapClient();
        ServiceReferencePedido.WSPedidoSoapClient servicioPedido = new ServiceReferencePedido.WSPedidoSoapClient();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BTBuscar_Click(object sender, EventArgs e)
        {
            GVInicial.DataSource = null;
            GVInicial.DataBind();
            string nombre = txtNombre.Text.Trim();
            DataTable a = new DataTable();
            a = servicioPedido.Buscar(nombre);
            GVInicial.DataSource = a;
            GVInicial.DataBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in GVInicial.Rows)
            {
                var check = (CheckBox)row.FindControl("CBSeleccionado");
                if (check.Checked)
                {
                    GVDetalle.DataSource = null;
                    GVDetalle.DataBind();
                    long id = Convert.ToInt64(row.Cells[11].Text.Trim());
                    txtCebo.Text = row.Cells[11].Text.Trim();
                    DataTable b = new DataTable();
                    b = servicioCarrito.ListarDetalles(id);
                    GVDetalle.DataSource = b;
                    GVDetalle.DataBind();
                    break;
                }
            }

        }

        protected void BTEliminar_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in GVDetalle.Rows)
            {
                var check = (CheckBox)row.FindControl("CBSeleccionado2");
                if (check.Checked)
                {
                    string  nombre =(row.Cells[1].Text.Trim());
                    servicioDetalle.Eliminar(nombre, Convert.ToInt64(txtCebo.Text.Trim()));  
                }
            }
                GVDetalle.DataSource = null;
                GVDetalle.DataBind();
                long id = Convert.ToInt64(txtCebo.Text);
                DataTable b = new DataTable();
                b = servicioCarrito.ListarDetalles(id);
                GVDetalle.DataSource = b;
                GVDetalle.DataBind();
        }
    }
}