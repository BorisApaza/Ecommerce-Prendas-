﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.IO;

using System.Web.UI.HtmlControls;
using System.Text;
namespace PaginaPrendas.Intranet
{
    public partial class Usuarios : System.Web.UI.Page
    {
        ServiceReference1.WSUsuarioSoapClient servicioUsuario = new ServiceReference1.WSUsuarioSoapClient();
        ServiceReferenceCarrito.WSCarritoSoapClient servicioCarrito = new ServiceReferenceCarrito.WSCarritoSoapClient();
        ServiceReferenceDetalle.WSDetalleSoapClient servicioDetalle = new ServiceReferenceDetalle.WSDetalleSoapClient();
        ServiceReferenceProducto.WSProductoSoapClient servicioProducto = new ServiceReferenceProducto.WSProductoSoapClient();
        ServiceReferencePedido.WSPedidoSoapClient servicioPedido = new ServiceReferencePedido.WSPedidoSoapClient();
        public double numeroCarrito = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void BTodosUsuarios_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 3;
        }

        protected void BTAgregarUsuario_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 2;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string User = TXTUsuario1.Text.Trim();
            string Com = TXTContraseña.Text.Trim();
            string[] val = servicioUsuario.Agregar(User,Com);
            MultiView1.ActiveViewIndex = 1;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in GVUsuario.Rows)
            {
                var check = (CheckBox)row.FindControl("CBSeleccionado");
                if (check.Checked)
                {
                    string nom = row.Cells[2].Text.Trim();
                    string[] val = servicioUsuario.Eliminar(nom);
                }
            }

            GVUsuario.DataSource = null;
            GVUsuario.DataBind();
            DataTable detalle = new DataTable();
            detalle = servicioUsuario.Buscar(" ");
            GVUsuario.DataSource = detalle;
            GVUsuario.DataBind();
        }

        protected void BTBuscar_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            GVUsuario.DataSource = null;
            GVUsuario.DataBind();
            DataTable prendas = new DataTable();
            prendas = servicioUsuario.Buscar(usuario);
            GVUsuario.DataSource = prendas;
            GVUsuario.DataBind();
        }

        protected void BTAgregarPrendasGV_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
        }

        protected void BTPrendasGV_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
        }

        protected void BTPrendaBuscar_Click(object sender, EventArgs e)
        {
            string nombrePrenda = TXTPrendaBuscar.Text.Trim();
            GVPrenda.DataSource = null;
            GVPrenda.DataBind();
            DataTable prendas = new DataTable();
            prendas = servicioProducto.Buscar(nombrePrenda);
            GVPrenda.DataSource = prendas;
            GVPrenda.DataBind();
                    }

        protected void BTEliminarPrenda_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in GVPrenda.Rows)
            {
                var check = (CheckBox)row.FindControl("CBSeleccionado");
                if (check.Checked)
                {
                    string nom = row.Cells[2].Text.Trim();
                    string[] val = servicioProducto.Eliminar(nom);
                }
            }

            GVPrenda.DataSource = null;
            GVPrenda.DataBind();
            DataTable detalle = new DataTable();
            detalle = servicioProducto.Buscar(" ");
            GVPrenda.DataSource = detalle;
            GVPrenda.DataBind();
        }

        protected void BTAgregarPrenda_Click(object sender, EventArgs e)
        {
            string nombre = TXTNombrePrenda.Text.Trim();
            string talla = TXTTallaPrenda.Text.Trim();
            string color = TXTColorPrenda.Text.Trim();
            long precio=Convert.ToInt64(TXTPrecioPrenda.Text.Trim());
            string[] val = servicioProducto.Agregar(nombre,color,talla,precio);
            MultiView1.ActiveViewIndex = 0;
        }

        protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e,int k)
        {
            e.Row.Cells[k].Visible = false;
        }
      

      
    }
}