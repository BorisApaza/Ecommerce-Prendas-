﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.IO;

using System.Web.UI.HtmlControls;
using System.Text;
namespace PaginaPrendas
{

    public partial class Pedido : System.Web.UI.Page
    {
        ServiceReferenceCarrito.WSCarritoSoapClient servicioCarrito = new ServiceReferenceCarrito.WSCarritoSoapClient();
        ServiceReferenceDetalle.WSDetalleSoapClient servicioDetalle = new ServiceReferenceDetalle.WSDetalleSoapClient();
        ServiceReferenceProducto.WSProductoSoapClient servicioProducto = new ServiceReferenceProducto.WSProductoSoapClient();
        ServiceReferencePedido.WSPedidoSoapClient servicioPedido = new ServiceReferencePedido.WSPedidoSoapClient();
        public double numeroCarrito = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                
                MVPedido.ActiveViewIndex = 1;
                string[] valores = servicioCarrito.Agregar(false).ToArray();
                numeroCarrito = servicioCarrito.Buscar();
                txtCebo.Text = numeroCarrito.ToString();
            }
        }
      

        protected void BTBuscarPrenda_Click(object sender, EventArgs e)
        {
            string nombrePrenda=txtPrenda.Text.Trim();
            GVPrendaBuscada.DataSource = null;
            GVPrendaBuscada.DataBind();
            DataTable prendas = new DataTable();
            prendas = servicioProducto.Buscar(nombrePrenda);
            GVPrendaBuscada.DataSource = prendas;
            GVPrendaBuscada.DataBind();
        }

        protected void GVPrendaBuscada_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void MultiView1_ActiveViewChanged(object sender, EventArgs e)
        {

        }

        protected void BTAgregarPrenda_Click(object sender, EventArgs e)
        {
               
                foreach(GridViewRow row in GVPrendaBuscada.Rows){
                     var check =(CheckBox)row.FindControl("CBSeleccionado");
                     var a = (TextBox)row.FindControl("txtCantidad");
                      if(check.Checked && a!=null){
                          string nombre = row.Cells[2].Text.Trim();
                          int b = Convert.ToInt16(a.Text);
                          long num = Convert.ToInt64(txtCebo.Text.Trim());
                          string[] valores = servicioDetalle.Agregar(nombre,num,b);
                      }
                   }

                GVDetalle.DataSource = null;
                GVDetalle.DataBind();
                DataTable detalle = new DataTable();
                detalle = servicioCarrito.ListarDetalles(Convert.ToInt64(txtCebo.Text.Trim()));
                GVDetalle.DataSource = detalle;
                GVDetalle.DataBind();
                

                }

        protected void BTGenrerarPedido_Click(object sender, EventArgs e)
        {
            int a = GVDetalle.Rows.Count;
            if (a > 0)
            {
                MVPedido.ActiveViewIndex = 0;
            }
           
            
            
        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Page.IsValid) {
                long carrito = Convert.ToInt64(txtCebo.Text.Trim());
                string[] valores = servicioPedido.Agregar(txtNombre.Text.Trim(), txtPaterno.Text.Trim(), txtMaterno.Text.Trim(),
                                                         txtCelular.Text.Trim(), txtCorreo.Text.Trim(), txtPais.Text.Trim(),
                                                         txtProvincia.Text.Trim(), txtDistrito.Text.Trim(), txtDireccion.Text.Trim(),
                                                         carrito);
                if (valores[0] == "0")
                {
                    Response.Write("Se genero su pedido, pronto se comunicara con usted");
                    Response.Redirect("Pedido.aspx");
                }
                else {
                    Response.Write("No se genero pedido, intentelo mas tarde");
                    Response.Redirect("Pedido.aspx");
                }
            }
        }

      


      
            
            }
           
        }

      
    
