use BDProyecto
go

create proc spLoginUsuario
@Usuario varchar(50), @Contrasena varchar(50)
as
begin
	if exists(select Usuario from Usuario where Usuario = @Usuario and Contrasena=@Contrasena)
		select CodError = 0, Mensaje = 'Ingreso Correcto'
	else select CodError = 1, Mensaje = 'Error: Usuario y/o Contrase�as Incorrectas'
end

insert into Usuario values('Juan','123','1')
spLoginUsuario 'Juan','123'


create proc spEliminarUsuario
@Usuario varchar(50)
as
begin
	if exists(select Usuario from Usuario where Usuario = @Usuario )
		begin
		delete Usuario from Usuario where Usuario = @Usuario
		select CodError = 0, Mensaje = 'Eliminacion correcta'
		end
	else select CodError =1, Mensaje= 'No existe Usuario'
end
spEliminarUsuario 'Carlos'

create proc spAgregarUsuario
@Usuario varchar(50), @Contrasena varchar(50)
as
begin
	if not exists(select Usuario from Usuario where Usuario = @Usuario )
		begin
		insert into Usuario(Usuario,Contrasena) values (@Usuario,@Contrasena)
		select CodError = 0, Mensaje = 'Agregar correcto'
		end
	else select CodError =1, Mensaje= 'Ya existe Usuario'
end

spAgregarUsuario 'Carlos','12345'

spEliminarUsuario 'Carlos'

create proc spListarUsuario
as
begin
	select * from Usuario
end
spListarUsuario

create proc spModificarUsuario
@Usuario varchar(50),@Usuario2 varchar(50),@Contrasena varchar(50)
as
begin
	if exists(select Usuario from Usuario where Usuario = @Usuario )
		begin
		if not exists(select Usuario from Usuario where Usuario = @Usuario2 )
			Update Usuario set Usuario= @Usuario2 , Contrasena=@Contrasena where Usuario=@Usuario
			select CodError = 0, Mensaje = 'Modificar correcto'
		end
	else select CodError =1, Mensaje= 'No se modifico, revise que exista usuario, y que no se repita el nuevo usuario'
end
spModificarUsuario 'Juan','Juan2','12'

create proc spBuscarUsuario
@Usuario varchar(50)
as
begin
	select * from Usuario where Usuario LIKE @Usuario+ '%'

end
spBuscarUsuario 'Ju'