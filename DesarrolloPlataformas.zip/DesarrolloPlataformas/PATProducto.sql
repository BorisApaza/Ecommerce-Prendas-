use BDProyecto

create proc spAgregarProducto
@Nombre varchar(50),@Color varchar(50),@Talla varchar(50),@Precio decimal(10,2)
as
begin
	if not exists(select Nombre from Producto where Nombre = @Nombre )
		begin
		insert into Producto  (Nombre,Color,Talla,Precio) values(@Nombre,@Color,@Talla,@Precio)
		 select CodError =0, Mensaje= 'Se agrego producto'
		end
	else select CodError =1, Mensaje= 'Ya existe producto con el mismo nombre'
end
spAgregarProducto 'polera','rojo','s','134.1'

create proc spEliminarProducto
@Nombre varchar(50)
as
begin
	if  exists(select Nombre from Producto where Nombre = @Nombre )
		begin
		declare @id bigint
		set @id=(select idProducto from Producto where nombre=@Nombre)
			begin
			delete Detalle_Producto where id_Producto=@id
			delete Producto where Nombre=@Nombre 
			select CodError =0, Mensaje= 'Se elimino producto'
			end
		end
	else select CodError =1, Mensaje= 'No existe producto '
end
spEliminarProducto 'pol'

create proc spListarProducto
as
	begin
	select * from Producto
	end
spListarProducto

create proc spModificarProducto
@Nombre varchar(50),@Nombre2 varchar(50),@Color varchar(50),@Talla varchar(50),@Precio decimal(10,2)
as
begin
	if not exists(select Nombre from Producto where Nombre = @Nombre2 )
		begin
		update Producto set Nombre=@Nombre2,Color=@Color,Talla=@Talla,Precio=@Precio
		 select CodError =0, Mensaje= 'Se modifico producto'
		end
	else select CodError =1, Mensaje= 'Ya existe producto con el mismo nombre'
end
spModificarProducto 'polera','polera2','rojo','s','134.1'

create proc spBuscarProducto
@Nombre varchar(50)
as
	begin
	select * from Producto where Nombre LIKE @Nombre +'%'
	end
spBuscarProducto 'pol'
