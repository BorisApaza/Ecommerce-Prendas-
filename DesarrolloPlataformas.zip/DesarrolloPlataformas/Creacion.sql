 
create database BDProyecto 
use BDProyecto
create table Producto(
	idProducto bigint IDENTITY(1,1) primary key ,
	Nombre varchar(30),
	Color varchar(20),
	Talla varchar(4),
	Precio decimal(10,2),
	Imagen varchar(30)
)

create table Carrito_Compras(
		idCarrito bigint IDENTITY(1,1) primary key,
		bug Bit 
)
create table Detalle_Producto(
	idDetalle bigint IDENTITY(1,1) primary key ,
	cantidad int,
	id_Producto bigint,
	id_Carrito bigint,
	foreign key (id_Producto) references Producto,
	foreign key (id_Carrito) references Carrito_Compras
)
create table Usuario(
	idUsuario bigint IDENTITY(1,1) primary key ,
	Usuario varchar(25) Unique,
	Contrasena varchar(25),
	Rango varchar(2)
)

create table Pedido(
	idPedido bigint IDENTITY(1,1) primary key ,
	NombreCliente varchar(30),
	APaternoCliente varchar(30),
	AMaternoCliente varchar(30),
	CelularCliente varchar(15),
	Correo varchar(30),
	Pais varchar(25),
	Provincia varchar(20),
	Distrito varchar(20),
	Direccion varchar(30),
	idCarrito bigint,
	idUsuario bigint,
	foreign key (idCarrito) references Carrito_Compras
)
